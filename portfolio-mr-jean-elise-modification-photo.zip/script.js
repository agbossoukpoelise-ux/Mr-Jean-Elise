(() => {
  const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  const selectors = [
    ['.stats','reveal'], ['#about > div:first-child','reveal-left'], ['.about-photo','clip-reveal'],
    ['#services .section-head','reveal-right'], ['#services .service-grid article','reveal'],
    ['#projects .section-head','reveal-left'], ['#skills .section-head','reveal-right'],
    ['#skills .skill-item','reveal'], ['.method .section-head','clip-reveal'], ['.method .steps article','reveal'],
    ['#testimonials .section-head','reveal-left'], ['#testimonials .testimonial-carousel','reveal-right'],
    ['#faq .section-head','reveal'], ['#faq .faq-list','clip-reveal'], ['#contact .contact-copy','reveal-left'], ['#contact form','reveal-right']
  ];
  selectors.forEach(([selector, cls], group) => {
    document.querySelectorAll(selector).forEach((el, i) => {
      el.classList.add(cls);
      if (cls === 'reveal' && group !== 0) el.style.transitionDelay = `${Math.min(i * 90, 420)}ms`;
    });
  });

  const observer = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      if (!entry.isIntersecting) return;
      entry.target.classList.add('show');
      if (entry.target.matches('.skill-item')) animateSkill(entry.target);
      if (entry.target.matches('.stats')) animateCounters(entry.target);
      observer.unobserve(entry.target);
    });
  }, {threshold: .16, rootMargin: '0px 0px -8% 0px'});
  document.querySelectorAll('.reveal,.reveal-left,.reveal-right,.clip-reveal,.skill-item,.stats').forEach(el => observer.observe(el));

  function animateCounters(scope) {
    if (scope.dataset.counted) return;
    scope.dataset.counted = '1';
    scope.querySelectorAll('[data-counter]').forEach(el => {
      const target = Number(el.dataset.counter || 0), suffix = el.dataset.suffix || '';
      const start = performance.now(), duration = 1800;
      const tick = now => {
        const p = Math.min(1, (now - start) / duration);
        const eased = 1 - Math.pow(1 - p, 3);
        el.textContent = `${Math.round(target * eased)}${suffix}`;
        if (p < 1) requestAnimationFrame(tick);
      };
      requestAnimationFrame(tick);
    });
  }

  function animateSkill(el) {
    if (el.dataset.animated) return;
    el.dataset.animated = '1';
    const target = Number(el.dataset.value || 0), bar = el.querySelector('i'), label = el.querySelector('strong');
    if (reduceMotion) { bar.style.width = target + '%'; label.textContent = target + '%'; return; }
    requestAnimationFrame(() => { bar.style.width = target + '%'; });
    const start = performance.now(), duration = 5000;
    const tick = now => {
      const p = Math.min(1, (now - start) / duration);
      const eased = 1 - Math.pow(1 - p, 3);
      label.textContent = `${Math.round(target * eased)}%`;
      if (p < 1) requestAnimationFrame(tick);
    };
    requestAnimationFrame(tick);
  }

  function createInfiniteCarousel(root, interval, direction = 1) {
    if (!root) return;
    const track = root.querySelector(':scope > .project-track, :scope > .testimonial-track');
    if (!track) return;
    const original = Array.from(track.children);
    if (original.length < 2) return;
    const clonesBefore = original.map(x => x.cloneNode(true));
    const clonesAfter = original.map(x => x.cloneNode(true));
    clonesBefore.reverse().forEach(x => track.insertBefore(x, track.firstChild));
    clonesAfter.forEach(x => track.appendChild(x));
    const total = original.length;
    let index = total;
    let timer = null;
    let busy = false;
    let paused = false;
    let touchStartX = 0;
    let touchDeltaX = 0;
    const dots = root.querySelector('.carousel-dots');
    const prev = root.querySelector('.carousel-arrow.prev');
    const next = root.querySelector('.carousel-arrow.next');

    const stepWidth = () => {
      const item = track.children[0];
      if (!item) return 0;
      const gap = parseFloat(getComputedStyle(track).gap || 0);
      return item.getBoundingClientRect().width + gap;
    };
    const position = (animate = true) => {
      track.style.transition = animate && !reduceMotion ? 'transform .95s cubic-bezier(.22,.7,.2,1)' : 'none';
      track.style.transform = `translate3d(${-index * stepWidth()}px,0,0)`;
      const active = ((index - total) % total + total) % total;
      Array.from(track.children).forEach((card, i) => card.classList.toggle('is-active', i === index));
      if (dots) Array.from(dots.children).forEach((dot, i) => dot.classList.toggle('active', i === active));
    };
    const normalize = () => {
      if (index >= total * 2) { index -= total; position(false); }
      if (index < total) { index += total; position(false); }
    };
    const go = delta => {
      if (busy) return;
      busy = true;
      index += delta;
      position(true);
      setTimeout(() => { normalize(); busy = false; }, reduceMotion ? 0 : 980);
    };
    const resetTimer = () => {
      clearInterval(timer);
      if (!reduceMotion) timer = setInterval(() => { if (!paused) go(direction); }, interval);
    };

    if (dots) {
      dots.innerHTML = '';
      original.forEach((_, i) => {
        const b = document.createElement('button');
        b.type = 'button';
        b.setAttribute('aria-label', `Aller au ${root.dataset.carousel === 'projects' ? 'projet' : 'témoignage'} ${i + 1}`);
        b.addEventListener('click', () => { index = total + i; position(true); resetTimer(); });
        dots.appendChild(b);
      });
    }
    prev?.addEventListener('click', () => { go(-1); resetTimer(); });
    next?.addEventListener('click', () => { go(1); resetTimer(); });
    root.addEventListener('mouseenter', () => paused = true);
    root.addEventListener('mouseleave', () => paused = false);
    root.addEventListener('touchstart', e => { paused = true; touchStartX = e.changedTouches[0].clientX; touchDeltaX = 0; }, {passive:true});
    root.addEventListener('touchmove', e => { touchDeltaX = e.changedTouches[0].clientX - touchStartX; }, {passive:true});
    root.addEventListener('touchend', () => {
      if (Math.abs(touchDeltaX) > 45) go(touchDeltaX > 0 ? -1 : 1);
      paused = false; resetTimer();
    }, {passive:true});
    window.addEventListener('resize', () => position(false));
    position(false); resetTimer();
  }

  // Projets : défilement automatique de gauche vers la droite toutes les 10 secondes.
  createInfiniteCarousel(document.querySelector('[data-carousel="projects"]'), 10000, -1);
  // Témoignages : carrousel automatique lent et infini.
  createInfiniteCarousel(document.querySelector('[data-carousel="testimonials"]'), 9000, 1);

  document.querySelectorAll('.faq-list details').forEach(detail => {
    detail.addEventListener('toggle', () => {
      if (detail.open && !reduceMotion) {
        const p = detail.querySelector('p');
        if (p) p.animate([{opacity:0, transform:'translateY(-8px)'},{opacity:1, transform:'translateY(0)'}], {duration:380, easing:'cubic-bezier(.2,.8,.2,1)', fill:'both'});
      }
    });
  });

  const heroVisual = document.querySelector('.hero-visual');
  if (heroVisual && !reduceMotion && window.matchMedia('(min-width: 900px)').matches) {
    let raf = 0;
    window.addEventListener('scroll', () => {
      if (raf) return;
      raf = requestAnimationFrame(() => {
        const rect = heroVisual.getBoundingClientRect();
        const offset = Math.max(-20, Math.min(20, (window.innerHeight / 2 - (rect.top + rect.height / 2)) * .035));
        heroVisual.style.transform = `translateY(${offset}px)`;
        raf = 0;
      });
    }, {passive:true});
  }

  if (!reduceMotion && window.matchMedia('(hover:hover) and (pointer:fine)').matches) {
    document.querySelectorAll('.magnetic').forEach(btn => {
      btn.addEventListener('pointermove', e => {
        const r = btn.getBoundingClientRect();
        const x = (e.clientX - r.left - r.width / 2) * .08;
        const y = (e.clientY - r.top - r.height / 2) * .08;
        btn.style.transform = `translate(${x}px,${y}px)`;
      });
      btn.addEventListener('pointerleave', () => btn.style.transform = 'translate(0,0)');
    });
    document.body.classList.add('custom-cursor');
    const dot = document.createElement('div'); dot.className = 'cursor-dot';
    const label = document.createElement('div'); label.className = 'cursor-label'; document.body.append(dot,label);
    window.addEventListener('pointermove', e => { dot.style.left=e.clientX+'px'; dot.style.top=e.clientY+'px'; label.style.left=e.clientX+'px'; label.style.top=e.clientY+'px'; });
    document.querySelectorAll('.project-track article').forEach(card => {
      card.addEventListener('mouseenter', () => { label.textContent='VIEW'; label.classList.add('on'); });
      card.addEventListener('mouseleave', () => label.classList.remove('on'));
    });
    document.querySelectorAll('.btn').forEach(btn => {
      btn.addEventListener('mouseenter', () => { label.textContent='CLICK'; label.classList.add('on'); });
      btn.addEventListener('mouseleave', () => label.classList.remove('on'));
    });
  }

  const menu = document.querySelector('.menu'), nav = document.querySelector('.header nav');
  menu?.addEventListener('click', () => { nav?.classList.toggle('mobile-open'); });
  nav?.querySelectorAll('a').forEach(a => a.addEventListener('click', () => nav.classList.remove('mobile-open')));

  const form = document.getElementById('contactForm');
  if (form) form.addEventListener('submit', e => {
    e.preventDefault();
    const d = new FormData(form);
    const subject = encodeURIComponent('Projet Shopify — ' + (d.get('name') || ''));
    const body = encodeURIComponent(`Nom : ${d.get('name')}\nEmail : ${d.get('email')}\nBudget : ${d.get('budget')}\n\nProjet :\n${d.get('message')}`);
    location.href = `mailto:agbossoukpoelise@gmail.com?subject=${subject}&body=${body}`;
  });

  document.querySelectorAll('video').forEach(v => {
    v.muted = true;
    v.setAttribute('playsinline','');
    v.addEventListener('mouseenter', () => v.play().catch(() => {}));
  });
})();
