MR JEAN ELISE — PORTFOLIO SHOPIFY

Version française — fond blanc / vert Shopify.

Le dossier est autonome : ouvrir index.html ou déployer le dossier directement sur Netlify / Cloudflare Pages.

Modifications principales :
- Hero avec l'ancienne photo portrait-hd.
- Section À propos avec la nouvelle photo et le logo Shopify fourni.
- Statistiques 300+ boutiques et 280+ clients.
- Section « Mes projets » avec carousel infini, défilement gauche vers droite toutes les 10 secondes et support tactile.
- Compétences avec chargement progressif de 0 à la valeur finale sur 5 secondes.
- Section Méthode avec titre et 6 étapes.
- Témoignages plus nombreux avec carousel infini.
- FAQ complète avec accordéons animés.
- Animations de scroll différentes selon les sections.
- Typographies Inter et Instrument Serif chargées via Google Fonts.
- Responsive desktop / tablette / mobile et prefers-reduced-motion.
